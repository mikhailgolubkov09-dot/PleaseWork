gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDGroundObjects1= [];
gdjs.Game_32SceneCode.GDGroundObjects2= [];
gdjs.Game_32SceneCode.GDObstacleObjects1= [];
gdjs.Game_32SceneCode.GDObstacleObjects2= [];
gdjs.Game_32SceneCode.GDPushableBoxObjects1= [];
gdjs.Game_32SceneCode.GDPushableBoxObjects2= [];
gdjs.Game_32SceneCode.GDPlayerObjects1= [];
gdjs.Game_32SceneCode.GDPlayerObjects2= [];
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrameObjects1= [];
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrameObjects2= [];
gdjs.Game_32SceneCode.GDxObjects1= [];
gdjs.Game_32SceneCode.GDxObjects2= [];
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrame2Objects1= [];
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrame2Objects2= [];


gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__VR__DisplayVRButton.func(runtimeScene, null);
}
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDGroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects1.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects2.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects1.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrameObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrameObjects2.length = 0;
gdjs.Game_32SceneCode.GDxObjects1.length = 0;
gdjs.Game_32SceneCode.GDxObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrame2Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrame2Objects2.length = 0;

gdjs.Game_32SceneCode.eventsList0(runtimeScene);
gdjs.Game_32SceneCode.GDGroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDGroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects1.length = 0;
gdjs.Game_32SceneCode.GDObstacleObjects2.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects1.length = 0;
gdjs.Game_32SceneCode.GDPushableBoxObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrameObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrameObjects2.length = 0;
gdjs.Game_32SceneCode.GDxObjects1.length = 0;
gdjs.Game_32SceneCode.GDxObjects2.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrame2Objects1.length = 0;
gdjs.Game_32SceneCode.GDGreenButtonWithStoneFrame2Objects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
