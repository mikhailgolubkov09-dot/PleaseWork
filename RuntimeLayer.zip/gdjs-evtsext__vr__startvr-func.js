
if (typeof gdjs.evtsExt__Vr__StartVR !== "undefined") {
  gdjs.evtsExt__Vr__StartVR.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__Vr__StartVR = {};
gdjs.evtsExt__Vr__StartVR.idToCallbackMap = new Map();


gdjs.evtsExt__Vr__StartVR.userFunc0xe75b28 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
runtimeScene.setBackgroundColor(100,100,240);
if (!gdjs._vrQuest2) {
  gdjs._vrQuest2 = {
    active: false,
    session: null,
    referenceSpace: null,
    head: {
      x: 0, y: 0, z: 0,
      yaw: 0, pitch: 0, roll: 0
    }
  };
}

const state = gdjs._vrQuest2;

if (!navigator.xr) {
  console.log("WebXR not supported");
  return;
}

navigator.xr.requestSession("immersive-vr").then((session) => {
  state.session = session;
  state.active = true;

  session.requestReferenceSpace("local-floor").then((refSpace) => {
    state.referenceSpace = refSpace;

    const onFrame = (time, frame) => {
      const pose = frame.getViewerPose(refSpace);

      if (pose) {
        const t = pose.transform;

        state.head.x = t.position.x;
        state.head.y = t.position.y;
        state.head.z = t.position.z;

        // УПРОЩЁННО: без углов пока
      }

      session.requestAnimationFrame(onFrame);
    };

    session.requestAnimationFrame(onFrame);
  });
});
};
gdjs.evtsExt__Vr__StartVR.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Vr__StartVR.userFunc0xe75b28(runtimeScene, eventsFunctionContext);

}


};

gdjs.evtsExt__Vr__StartVR.func = function(runtimeScene, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("Vr"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("Vr"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__Vr__StartVR.eventsList0(runtimeScene, eventsFunctionContext);


return;
}

gdjs.evtsExt__Vr__StartVR.registeredGdjsCallbacks = [];