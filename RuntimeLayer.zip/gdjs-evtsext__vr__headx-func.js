
if (typeof gdjs.evtsExt__Vr__HeadX !== "undefined") {
  gdjs.evtsExt__Vr__HeadX.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__Vr__HeadX = {};
gdjs.evtsExt__Vr__HeadX.idToCallbackMap = new Map();


gdjs.evtsExt__Vr__HeadX.userFunc0xbbfad0 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
runtimeScene.setBackgroundColor(100,100,240);
if (!gdjs._vrQuest2 || !gdjs._vrQuest2.head) {
  eventsFunctionContext.returnValue = 0;
  return;
}

eventsFunctionContext.returnValue = gdjs._vrQuest2.head.x;
};
gdjs.evtsExt__Vr__HeadX.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__Vr__HeadX.userFunc0xbbfad0(runtimeScene, eventsFunctionContext);

}


};

gdjs.evtsExt__Vr__HeadX.func = function(runtimeScene, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("Vr"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("Vr"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__Vr__HeadX.eventsList0(runtimeScene, eventsFunctionContext);


return Number(eventsFunctionContext.returnValue) || 0;
}

gdjs.evtsExt__Vr__HeadX.registeredGdjsCallbacks = [];